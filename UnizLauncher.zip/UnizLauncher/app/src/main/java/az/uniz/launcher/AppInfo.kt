package az.uniz.launcher

import android.content.Intent
import android.graphics.drawable.Drawable

data class AppInfo(val label: String, val pkg: String, val icon: Drawable, val intent: Intent)
