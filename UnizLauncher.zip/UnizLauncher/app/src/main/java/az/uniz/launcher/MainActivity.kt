package az.uniz.launcher

import android.content.*
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {

    private val prefs by lazy { getSharedPreferences("uniz", MODE_PRIVATE) }
    private var allApps: List<AppInfo> = emptyList()
    private lateinit var favAdapter: AppAdapter
    private lateinit var allAdapter: AppAdapter
    private lateinit var drawer: View
    private lateinit var search: EditText
    private lateinit var emptyFav: TextView
    private val io = Executors.newSingleThreadExecutor()

    private val pkgReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) = loadApps()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        drawer = findViewById(R.id.drawer)
        search = findViewById(R.id.search)
        emptyFav = findViewById(R.id.emptyFav)

        favAdapter = AppAdapter({ launch(it) }, { togglePin(it) })
        allAdapter = AppAdapter({ launch(it); closeDrawer() }, { togglePin(it) })

        findViewById<RecyclerView>(R.id.favList).apply {
            layoutManager = GridLayoutManager(this@MainActivity, 5); adapter = favAdapter
        }
        findViewById<RecyclerView>(R.id.appList).apply {
            layoutManager = GridLayoutManager(this@MainActivity, 8); adapter = allAdapter
        }

        findViewById<View>(R.id.btnAllApps).setOnClickListener { openDrawer() }
        findViewById<View>(R.id.tileNav).setOnClickListener { openNavigation() }
        findViewById<View>(R.id.tileMusic).setOnClickListener {
            startSafe(Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_MUSIC))
        }
        findViewById<View>(R.id.tilePhone).setOnClickListener { startSafe(Intent(Intent.ACTION_DIAL)) }
        findViewById<View>(R.id.tileSettings).setOnClickListener { startSafe(Intent(Settings.ACTION_SETTINGS)) }

        search.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) = filter(s?.toString().orEmpty())
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })

        registerReceiver(pkgReceiver, IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED); addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_REPLACED); addDataScheme("package")
        })
        loadApps()
    }

    override fun onDestroy() { unregisterReceiver(pkgReceiver); io.shutdown(); super.onDestroy() }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        if (intent?.action == Intent.ACTION_MAIN) closeDrawer()   // Home düyməsi
    }

    override fun onBackPressed() { if (drawer.visibility == View.VISIBLE) closeDrawer() }

    private fun openDrawer() { search.setText(""); drawer.visibility = View.VISIBLE }
    private fun closeDrawer() { drawer.visibility = View.GONE }

    private fun loadApps() {
        io.execute {
            val pm = packageManager
            val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val list = pm.queryIntentActivities(q, 0)
                .filter { it.activityInfo.packageName != packageName }
                .map {
                    val pkg = it.activityInfo.packageName
                    AppInfo(
                        it.loadLabel(pm).toString(), pkg, it.loadIcon(pm),
                        Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
                            .setClassName(pkg, it.activityInfo.name)
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
                    )
                }
                .distinctBy { it.intent.component }
                .sortedBy { it.label.lowercase() }
            runOnUiThread {
                allApps = list
                if (!prefs.contains("pinned")) savePinned(list.take(10).map { it.pkg })
                allAdapter.submit(list); refreshFav()
            }
        }
    }

    private fun filter(q: String) {
        allAdapter.submit(if (q.isBlank()) allApps else allApps.filter { it.label.contains(q, true) })
    }

    private fun pinned(): List<String> =
        prefs.getString("pinned", "").orEmpty().split(",").filter { it.isNotBlank() }

    private fun savePinned(l: List<String>) = prefs.edit().putString("pinned", l.joinToString(",")).apply()

    private fun refreshFav() {
        val p = pinned()
        val list = p.mapNotNull { pk -> allApps.firstOrNull { it.pkg == pk } }
        favAdapter.submit(list)
        emptyFav.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun togglePin(app: AppInfo) {
        val p = pinned().toMutableList()
        if (p.remove(app.pkg)) toast(R.string.unpinned) else { p.add(app.pkg); toast(R.string.pinned) }
        savePinned(p); refreshFav()
    }

    private fun launch(app: AppInfo) = startSafe(app.intent)

    private fun openNavigation() {
        val known = listOf("com.google.android.apps.maps", "com.waze", "ru.yandex.yandexnavi",
            "ru.yandex.yandexmaps", "com.sygic.aura", "com.here.app.maps", "com.autonavi.minimap")
        val pm = packageManager
        val pkg = known.firstOrNull { pm.getLaunchIntentForPackage(it) != null }
        val i = pkg?.let { pm.getLaunchIntentForPackage(it) }
            ?: Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_MAPS)
        startSafe(i)
    }

    private fun startSafe(i: Intent) {
        try { startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        catch (e: Exception) { toast(R.string.not_found) }
    }

    private fun toast(res: Int) = Toast.makeText(this, res, Toast.LENGTH_SHORT).show()
}
