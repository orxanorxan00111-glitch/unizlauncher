# UNIZ Launcher
Android 9 (API 28), Full HD (1920x1080) landscape üçün yeni launcher. Orijinal B561 launcherə toxunmur.

## Yığmaq
1. Android Studio (Hedgehog və ya yeni) → File > Open → bu qovluq.
2. Gradle sync gözlə → Build > Build APK(s). Nəticə: app/build/outputs/apk/debug/app-debug.apk
3. APK-nı qurğuya qur (USB/fləş). Home düyməsinə basanda "həmişə" / default launcher seç.
Orijinal launcher qalır, istənilən vaxt geri qayıda bilərsən.

## Xüsusiyyətlər
Böyük saat/tarix, 4 sürətli kart (naviqasiya, musiqi, telefon, ayarlar), sevimli tətbiqlər şəbəkəsi,
axtarışlı "Bütün tətbiqlər", tətbiqə uzun basaraq sevimli et/çıxar, tünd müasir tema.
